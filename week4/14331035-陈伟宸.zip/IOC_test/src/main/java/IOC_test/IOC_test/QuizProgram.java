package IOC_test.IOC_test;

public class QuizProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuizMasterService quizMasterService = new QuizMasterService();
		quizMasterService.askQuestion();
	}

}
