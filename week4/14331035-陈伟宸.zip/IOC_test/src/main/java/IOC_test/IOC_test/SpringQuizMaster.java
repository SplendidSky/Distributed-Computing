package IOC_test.IOC_test;

public class SpringQuizMaster implements QuizMaster {

	public String popQuestion() {
		return "Are you new to Spring?";
	}

}