package IOC_test.IOC_test;

public interface QuizMaster {
	public String popQuestion();
}
