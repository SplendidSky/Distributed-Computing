package IOC_test.IOC_test;

public class StrutsQuizMaster implements QuizMaster {

	public String popQuestion() {
		return "Are you new to Struts?";
	}

}